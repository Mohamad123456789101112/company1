import { readFile } from "node:fs/promises";
import path from "node:path";
import { CheckCircle2, Database, Globe, KeyRound, Rocket, ShieldCheck } from "lucide-react";
import { requireAdmin } from "@/lib/auth";
import { isGoogleConfigured } from "@/lib/google";
import { CopyButton } from "@/components/ui-client";
import { Alert, Badge, PageHeader } from "@/components/ui";

export default async function SetupPage() {
  await requireAdmin();
  let sqlText = "-- لم يتم العثور على الملف supabase/schema.sql";
  try {
    sqlText = await readFile(path.join(process.cwd(), "supabase", "schema.sql"), "utf8");
  } catch {
    /* ignore */
  }
  const envOk = {
    db: Boolean(process.env.DATABASE_URL),
    appUrl: Boolean(process.env.NEXT_PUBLIC_APP_URL),
    google: isGoogleConfigured(),
    adminEmails: Boolean(process.env.ADMIN_EMAILS),
    vercel: Boolean(process.env.VERCEL),
  };

  const Step = ({ n, icon: Icon, title, children }: { n: number; icon: typeof Database; title: string; children: React.ReactNode }) => (
    <section className="card p-6">
      <h2 className="flex items-center gap-3 text-base font-black text-slate-900">
        <span className="grid size-9 place-items-center rounded-xl bg-emerald-500/15 text-emerald-700"><Icon className="size-5" /></span>
        <span className="text-xs text-slate-500">خطوة {n}</span> {title}
      </h2>
      <div className="prose-ar mt-4 space-y-2">{children}</div>
    </section>
  );

  return (
    <div className="space-y-6">
      <PageHeader eyebrow="التشغيل" title="دليل التشغيل: Supabase • Vercel • Google" subtitle="3 خطوات فقط لتشغيل المنصة على الإنترنت" />

      <div className="grid gap-3 sm:grid-cols-5">
        {[
          { k: "DATABASE_URL", ok: envOk.db },
          { k: "NEXT_PUBLIC_APP_URL", ok: envOk.appUrl },
          { k: "GOOGLE_CLIENT_ID/SECRET", ok: envOk.google },
          { k: "ADMIN_EMAILS", ok: envOk.adminEmails },
          { k: "Vercel", ok: envOk.vercel },
        ].map((e) => (
          <div key={e.k} className="card flex items-center justify-between gap-2 px-3 py-2.5 text-xs">
            <span className="font-mono text-slate-700" dir="ltr">{e.k}</span>
            <Badge tone={e.ok ? "success" : "warning"}>{e.ok ? "جاهز" : "ناقص"}</Badge>
          </div>
        ))}
      </div>

      <Step n={1} icon={Database} title="قاعدة البيانات على Supabase">
        <p>1. أنشئ مشروعًا جديدًا على <b>supabase.com</b> ثم افتح <b>SQL Editor</b> والصق الكود التالي بالكامل واضغط <b>Run</b>.</p>
        <p>2. من <b>Project Settings → Database → Connection string (URI)</b> انسخ رابط الاتصال (استخدم Session pooler على المنفذ 5432) وضعه في المتغير <code className="rounded bg-slate-200 px-1" dir="ltr">DATABASE_URL</code>.</p>
        <div className="mt-3 flex items-center justify-between">
          <p className="text-xs text-slate-500">الملف: <code dir="ltr">supabase/schema.sql</code> – يُنشئ كل الجداول والفهارس والإعدادات وحساب المدير الافتراضي.</p>
          <CopyButton text={sqlText} label="نسخ كود SQL كاملًا" />
        </div>
        <textarea readOnly dir="ltr" className="input mt-2 h-72 font-mono text-[11px] leading-5" value={sqlText} />
        <Alert tone="warning" className="mt-3">
          حساب المدير الافتراضي: <b dir="ltr">admin@mohamedfawzi.com</b> / كلمة المرور <b dir="ltr">Admin@12345</b> — غيّر كلمة المرور فور أول دخول. يمكنك أيضًا وضع بريدك في <code dir="ltr">ADMIN_EMAILS</code> ليُرقّى حسابك لمدير تلقائيًا عند التسجيل.
        </Alert>
      </Step>

      <Step n={2} icon={Rocket} title="الرفع على Vercel">
        <p>1. ارفع المشروع على GitHub ثم استورده في <b>vercel.com → New Project</b>.</p>
        <p>2. أضف متغيرات البيئة التالية في <b>Settings → Environment Variables</b>:</p>
        <pre className="overflow-x-auto rounded-xl border border-slate-200 bg-white-2 p-4 font-mono text-[11px] leading-6 text-slate-700" dir="ltr">{`DATABASE_URL=postgresql://postgres.xxxx:PASSWORD@aws-0-eu-central-1.pooler.supabase.com:5432/postgres
NEXT_PUBLIC_APP_URL=https://your-domain.vercel.app
ADMIN_EMAILS=you@gmail.com
GOOGLE_CLIENT_ID=xxxx.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=GOCSPX-xxxx`}</pre>
        <p>3. اضغط <b>Deploy</b>. بعد الربط بدومين خاص حدّث <code dir="ltr">NEXT_PUBLIC_APP_URL</code> وأعد النشر.</p>
      </Step>

      <Step n={3} icon={KeyRound} title="تسجيل الدخول عبر Google">
        <p>1. افتح <b>console.cloud.google.com → APIs & Services → Credentials → Create OAuth client ID</b> (نوع Web application).</p>
        <p>2. في <b>Authorized redirect URIs</b> أضف:</p>
        <pre className="rounded-xl border border-slate-200 bg-white-2 p-3 font-mono text-[11px] text-slate-700" dir="ltr">{`${process.env.NEXT_PUBLIC_APP_URL ?? "https://your-domain.vercel.app"}/api/auth/google/callback`}</pre>
        <p>3. انسخ Client ID و Client Secret إلى متغيرات البيئة في Vercel ثم أعد النشر. سيظهر زر Google تلقائيًا في صفحتي الدخول والتسجيل.</p>
        <p className="flex items-center gap-2 text-xs"><Globe className="size-4 text-brand-400" /> الحالة الآن: {envOk.google ? <Badge tone="success">مفعّل</Badge> : <Badge tone="warning">غير مفعّل – المتغيرات ناقصة</Badge>}</p>
      </Step>

      <section className="card p-6">
        <h2 className="flex items-center gap-2 text-base font-black text-slate-900"><ShieldCheck className="size-5 text-emerald-600" /> إجراءات الأمان المفعّلة</h2>
        <ul className="mt-3 grid gap-2 text-sm text-slate-700 sm:grid-cols-2">
          {[
            "حد أقصى 5 محاولات دخول لكل حساب و20 لكل IP كل 15 دقيقة (Brute-force)",
            "قفل الحساب تلقائيًا بعد 5 محاولات فاشلة (15 دقيقة) و10 (ساعة)",
            "تشفير كلمات المرور bcrypt (cost 12) مع معادلة توقيت ضد التخمين",
            "جلسات مخزنة بقاعدة البيانات (SHA-256) مع حد للأجهزة وإمكانية الفصل",
            "كوكيز HttpOnly + Secure + SameSite وحماية CSRF المدمجة في Server Actions",
            "رؤوس أمان: CSP, HSTS, X-Frame-Options, nosniff, Referrer-Policy, Permissions-Policy",
            "Google OAuth مع PKCE و state موقّع ضد CSRF",
            "التحقق من كل المدخلات بـ Zod + استعلامات مُعاملة (لا SQL Injection)",
            "حد للطلبات على الأكواد والتسجيل والتواصل وطلبات الدفع",
            "عمليات المحفظة ذرّية (لا إنفاق مزدوج) وسجل تدقيق كامل",
            "روابط الفيديو لا تُرسل أبدًا لغير المشتركين + علامة مائية بهوية الطالب",
            "حماية من Open Redirect وIDOR (كل استعلام مقيّد بهوية المستخدم)",
          ].map((t) => <li key={t} className="flex items-start gap-2"><CheckCircle2 className="mt-1 size-3.5 shrink-0 text-emerald-600" /> {t}</li>)}
        </ul>
      </section>

    </div>
  );
}
