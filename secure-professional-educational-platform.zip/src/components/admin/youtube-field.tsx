"use client";

import { useMemo, useState } from "react";
import { CheckCircle2, ExternalLink, Eye, EyeOff, AlertTriangle } from "lucide-react";
import { YoutubeIcon } from "@/components/icons";
import { Field, Input } from "@/components/ui";
import { extractYouTubeId } from "@/lib/utils";

/**
 * "رابط الفيديو من يوتيوب" field: validates the link instantly, shows the
 * thumbnail + an optional private preview, and reminds the teacher to upload
 * the video as UNLISTED. The stored value is just the URL (a few bytes in DB).
 */
export function YouTubeField({ defaultValue }: { defaultValue?: string | null }) {
  const [value, setValue] = useState(defaultValue ?? "");
  const [preview, setPreview] = useState(false);
  const id = useMemo(() => (value.trim() ? extractYouTubeId(value.trim()) : null), [value]);
  const invalid = value.trim().length > 0 && !id;

  return (
    <div className="space-y-3">
      <Field label="رابط الفيديو من يوتيوب" name="l_video" error={invalid ? "الرابط غير صالح – انسخه من زر «مشاركة» في يوتيوب" : undefined} hint="ارفع الشرح على قناتك بحالة «غير مدرج (Unlisted)» ثم الصق الرابط هنا – المنصة تخزّن الرابط فقط ولا يراه إلا الطالب المشترك">
        <div className="relative">
          <YoutubeIcon className="pointer-events-none absolute right-3 top-1/2 size-5 -translate-y-1/2 text-rose-500" />
          <Input id="l_video" name="videoUrl" value={value} onChange={(e) => setValue(e.target.value)} dir="ltr" placeholder="https://youtu.be/XXXXXXXXXXX" className="pr-10" autoComplete="off" />
          {id && <CheckCircle2 className="pointer-events-none absolute left-3 top-1/2 size-5 -translate-y-1/2 text-emerald-500" />}
        </div>
      </Field>

      {id && (
        <div className="overflow-hidden rounded-2xl border border-lav-200 bg-white">
          <div className="flex items-center justify-between gap-2 border-b border-lav-200 bg-lav-50 px-3 py-2 text-[11px]">
            <span className="flex items-center gap-1.5 font-bold text-emerald-700"><CheckCircle2 className="size-3.5" /> تم التعرف على الفيديو <span className="font-mono text-slate-500" dir="ltr">({id})</span></span>
            <span className="flex items-center gap-2">
              <button type="button" onClick={() => setPreview((p) => !p)} className="flex items-center gap-1 font-bold text-brand-600 hover:underline">{preview ? <EyeOff className="size-3.5" /> : <Eye className="size-3.5" />} {preview ? "إخفاء المعاينة" : "معاينة"}</button>
              <a href={`https://youtu.be/${id}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-slate-500 hover:text-slate-800"><ExternalLink className="size-3.5" /> فتح</a>
            </span>
          </div>
          {preview ? (
            <div className="aspect-video w-full bg-black">
              <iframe src={`https://www.youtube-nocookie.com/embed/${id}?rel=0&modestbranding=1`} className="size-full" title="معاينة" allow="autoplay; encrypted-media; fullscreen" allowFullScreen />
            </div>
          ) : (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={`https://i.ytimg.com/vi/${id}/hqdefault.jpg`} alt="" className="aspect-video w-full object-cover" loading="lazy" />
          )}
        </div>
      )}

      <details className="rounded-2xl border border-amber-200 bg-amber-50/70 text-xs leading-6 text-amber-900">
        <summary className="flex cursor-pointer items-center gap-2 px-3 py-2 font-bold"><AlertTriangle className="size-4" /> كيف أرفع الفيديو «غير مدرج» على يوتيوب؟ (مهم جدًا)</summary>
        <ol className="list-inside list-decimal space-y-1 px-4 pb-3">
          <li>افتح <span dir="ltr">studio.youtube.com</span> → «إنشاء» → «تحميل فيديوهات» واختر ملف الشرح.</li>
          <li>في خطوة «مستوى الظهور» اختر <b>غير مدرج (Unlisted)</b> – وليس «عام» ولا «خاص».</li>
          <li>بعد انتهاء المعالجة اضغط «مشاركة» وانسخ الرابط والصقه في الخانة أعلاه.</li>
          <li>مهم: اترك خيار «السماح بالتضمين» <b>مفعّلًا</b> (وإلا لن يعمل داخل المنصة)، ويمكنك تعطيل «التعليقات» وإلغاء إضافة الفيديو لأي قائمة تشغيل عامة.</li>
        </ol>
      </details>
    </div>
  );
}
